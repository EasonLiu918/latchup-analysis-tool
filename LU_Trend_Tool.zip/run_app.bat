@echo off
echo Starting Latchup Tool...
call .venv\Scripts\python.exe app_gui.py
pause