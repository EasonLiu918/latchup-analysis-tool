import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
from src.list_test_nodes import get_node_names
from src.plot_lu_trend import load_node_data
from src.plot_lu_trend import convert_current, convert_voltage
from src.plot_lu_trend import split_stage
from src.plot_lu_trend import plot_iv
from src.extract_latchup_table import process_excel
# 11 Embed matplotlib figure in tkinter / 將 matplotlib 圖嵌入 tkinter
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

# 1 Create the main window / 建立視窗
root = tk.Tk()

# 20 Store selected Excel path / 儲存使用者選到的 Excel 路徑
excel_path_var = tk.StringVar(value="")

# 21 Function to select Excel file / 選擇 Excel 檔案的函式
def select_excel():
    file_path = filedialog.askopenfilename(
        title="Select Excel file",
        filetypes=[("Excel files", "*.xlsx")]
    )

    if file_path:
        excel_path_var.set(file_path)
        print("Selected Excel: ",file_path)
        new_node_list = get_node_names(file_path) # 24 Read new Excel to get new list / 讀新的EXCEL 取得node list
        update_node_dropdown(new_node_list) # 24 Update dropdown / 更新下拉選單
        #print(type(new_node_list))
        #print(new_node_list[:5])

# 26 Define a function to process excel / 定義函式去執行 Excel 抽表流程的函式
def run_process_excel():
    excel_path= excel_path_var.get()
    if not excel_path:
        print("Please select an Excel file first.")
        return
    
    print("Processing Excel:", excel_path)
    process_excel(excel_path)
    print("Process Excel done!")

# 23 Define a function to update node list / 定義函式去更新node_list
def update_node_dropdown(new_node_list):
    dropdown["values"] = new_node_list

    if new_node_list:
        selected_node.set(new_node_list[0])

# 5 Define a function to execute button click / 定義函式執行按鈕點擊
def on_button_click():
    node = selected_node.get()

    print("Selected node: ", node)

    df = load_node_data(node) # 6 Load CSV data / 讀取這個node的資料

    df = convert_current(df) # 7 Convert current to mA / 將電流轉為mA
    df = convert_voltage(df) # 7 Convert voltage to V / 將電壓轉為V

    # 8 Split data into stage / 將資料分成 pre / stress / post
    df_pre, df_stress, df_post = split_stage(df) 
    print("Pre:", len(df_pre))
    print("Stress:", len(df_stress))
    print("Post: ", len(df_post))

    # 16 Get selected stages / 取得使用者選擇的stage
    selected_stages = []
    if pre_var.get():
        selected_stages.append("pre")
    if stress_var.get():
        selected_stages.append("stress")
    if post_var.get():
        selected_stages.append("post")
        
    print("Selected stage: ", selected_stages)

    # 19 Get selected is/vs list / 取得使用者選擇的is/vs list
    selected_vslist = []
    if vs1_var.get():
        selected_vslist.append(1)
    if vs2_var.get():
        selected_vslist.append(2)
    if vs3_var.get():
        selected_vslist.append(3)
    if vs4_var.get():
        selected_vslist.append(4)
    if vs5_var.get():
        selected_vslist.append(5)

    print("Selected vslist: ", selected_vslist)

    # 9 Plot IV curve / 繪製 IV 曲線
    fig = plot_iv(df_pre, df_stress, df_post, node, stage=selected_stages, vs_list=selected_vslist)

    # 12 Clear previous plot / 清除舊圖
    for widget in plot_frame.winfo_children():
        widget.destroy()

# 13 Create a frame for controls / 建立控制區(放按鈕\選單)
control_frame = tk.Frame(root)
control_frame.pack(pady=10)

# 2 Create a label / 添加標籤
label = tk.Label(control_frame, 
                 text="Latch-up IV Curve Viewer",
                 font=("Arial", 16, "bold")
                 )
label.pack(pady=10)

# 25 Get inital node list / 取得初始的node list
node_names_list = get_node_names()

# 3 Create a varible to store selected node / 建立變數來存儲選到的node
selected_node = tk.StringVar(root)
selected_node.set(node_names_list[0])

# 22 Create Select Excel button / 建立選擇Excel 的按鈕
excel_button = tk.Button(
    control_frame, 
    text="Select Excel", 
    command=select_excel,
    width=20
    )
excel_button.pack(pady=5)

# 22 Create Process Excel button / 建立執行Excel 的按鈕
process_button = tk.Button(
    control_frame, 
    text="Process Excel", 
    command=run_process_excel,
    width=20
    )
process_button.pack(pady=5)

# 3 Create a dropdown menu for node selection / 建立 node 下拉選單
dropdown = ttk.Combobox(
    control_frame, 
    textvariable=selected_node, 
    values=node_names_list, 
    state="readonly"
)
#dropdown.config(width=30)
dropdown.pack(pady=10)

# 14 Create a frame for stage selection / 建立stage 選擇區
stage_frame = tk.Frame(control_frame)
stage_frame.pack(pady=5)

# 15 Create varibles for stage selection / 建立勾選狀態變數
pre_var = tk.BooleanVar(value=True)
stress_var = tk.BooleanVar(value=True)
post_var = tk.BooleanVar(value=True)

# 15 Create checkboxs / 建立三個勾選框
pre_cb = tk.Checkbutton(stage_frame, text="Pre", variable=pre_var)
pre_cb.pack(side="left", padx=5)

stress_cb = tk.Checkbutton(stage_frame, text="Stress", variable=stress_var)
stress_cb.pack(side="left", padx=5)

post_cb = tk.Checkbutton(stage_frame, text="Post", variable=post_var)
post_cb.pack(side="left", padx=5)

# 17 Create a frame for vs selection / 建立 vs 選擇區
vs_frame = tk.Frame(control_frame)
vs_frame.pack(pady=5)

# 18 Create varibles for is/vslist selection / 建立勾選狀態變數
vs1_var = tk.BooleanVar(value=True)
vs2_var = tk.BooleanVar(value=True)
vs3_var = tk.BooleanVar(value=True)
vs4_var = tk.BooleanVar(value=True)
vs5_var = tk.BooleanVar(value=True)

# 18 Create checkboxs / 建立五個勾選框
vs1_cb = tk.Checkbutton(vs_frame, text="Vs1/Is1", variable=vs1_var)
vs1_cb.pack(side="left", padx=5)

vs2_cb = tk.Checkbutton(vs_frame, text="Vs2/Is2", variable=vs2_var)
vs2_cb.pack(side="left", padx=5)

vs3_cb = tk.Checkbutton(vs_frame, text="Vs3/Is3", variable=vs3_var)
vs3_cb.pack(side="left",padx=5)

vs4_cb = tk.Checkbutton(vs_frame, text="Vs4/Is4", variable=vs4_var)
vs4_cb.pack(side="left",padx=5)

vs5_cb = tk.Checkbutton(vs_frame, text="Vs5/Is5", variable=vs5_var)
vs5_cb.pack(side="left",padx=5)

# 4 Create a Button / 添加按鈕
button = tk.Button(control_frame, text="Plot IV curve", command=on_button_click)
button.pack()

# 10 Create a frame for plotting / 建立區域防圖
plot_frame = tk.Frame(root)
plot_frame.pack(pady=20)
root.mainloop()