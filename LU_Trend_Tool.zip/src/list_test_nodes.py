from pathlib import Path
DEFAULT_EXCEL = Path("data") / "281182_39.export.xlsx"

import pandas as pd

def get_node_names(excel_path=DEFAULT_EXCEL):
    df = pd.read_excel(excel_path, sheet_name="Summary", header=None, usecols="A:B", engine="openpyxl")
    #print(df)
    
    # 1) Get column A (df[0]) and normalize text / 取得 A 欄（df[0]）
    a = df[0].fillna("").str.strip()
    # 2) Build a boolean mask where A == "Setup Stress Levels" / A 欄等於 "Setup Stress Levels"
    mask = a.eq("Setup Stress Levels")
    # 3) Select column B (df[1]) for rows that match the mask / 取出 B 欄（df[1]）
    b = df.loc[mask,1]
    # 4) Clean column B values / 清理B欄
    b = b.dropna().str.strip()
    # 5) drop_duplicates / 去重複
    nodes = b.drop_duplicates()
    
    # 6-1  Remove prefix "{Part of " / 移除前綴 "{Part of "
    node_names = nodes.str.replace(r"^\{Part of ","", regex=True)
    # 6-2  Remove suffix "}" / 移除後綴 "}"
    node_names = node_names.str.replace(r"\}$","",regex=True)
    
    # 7 Convert to list / 轉成list
    node_names_list = node_names.tolist()

    print(len(node_names_list))
    print(node_names_list)

    return node_names_list

# 只有直接執行此檔案時才會跑 main()（避免被 GUI import 時自動執行）
if __name__ == "__main__":
    nodes = get_node_names()
    #print(nodes)