from pathlib import Path
DEFAULT_EXCEL = Path("data") / "281182_39.export.xlsx"
#EXCEL = Path("data") / "281182_39.export.xlsx"

import pandas as pd
# 26 Define function to load summary sheet from Excel 
# 26 定義函式：從Excel 讀取 Summar 工作表
def load_summary_df(excel_path=DEFAULT_EXCEL):
    df = pd.read_excel(
    excel_path, 
    sheet_name="Summary", 
    header=None, 
    usecols="A:B", 
    engine="openpyxl"
    )
    return df

# 27 Define function to get raw node list, cleaned node list, and node pairs
# 27 定義函式：取得原始 node 清單、清理後的 node 清單，以及對應 pair
def get_node_pairs(df):
    # 1) Normalize column A  / 清洗 A 欄文字
    colA = df[0].fillna("").str.strip()

    # 2) Get row indice of anchors  / 取得 anchor 的列索引
    idx = df.index[colA.eq("Setup Stress Levels")]

    # 3) Normalize column B  / 清洗 B 欄文字
    colB = df[1].fillna("").str.strip()
    raw_nodes = colB.loc[idx]
    # print(raw_nodes_lists)

    # 4-1)  Remove prefix "{Part of " / 移除前綴 "{Part of "
    node_names = raw_nodes.str.replace(r"^\{Part of ","", regex=True)
    # 4-2)  Remove suffix "}" / 移除後綴 "}"
    node_names = node_names.str.replace(r"\}$","",regex=True)

    # 5)  Convert to list / 轉成list
    raw_nodes_list = raw_nodes.tolist()
    node_names_list = node_names.drop_duplicates().tolist()
    #print(node_names_list)
    #print(len(raw_nodes_list), len(node_names_list))

    # 18 Build pair / 建立pair
    pairs_all = list(zip(raw_nodes_list, node_names_list))
    #print(pairs_all)
    return raw_nodes_list, node_names_list, pairs_all


# 23 Define function to locate the data start position for a given node
# 23 定義函式：找出指定 node 的資料起點（header 與 data 起始列)
def get_data_start(df, target):
    colA = df[0].fillna("").str.strip()

    # 7) Find start row (Excel row number) / 找到起始列
    start_i = df.index[colA.eq("Setup Stress Levels") & df[1].fillna("").str.strip().eq(target)][0]
    start_row = start_i + 1

    # 8) Find title row after start_row / 從 start_row 往下找標題列
    mask_title = colA.eq("LATCHUP DETAILED DATA") & (df.index >= start_row - 1)
    
    # 9) Get title row (Excel row number) / 取得標題列
    title_row = df.index[mask_title][0] + 1

    # 10) header and data start rows / 表頭列與資料起始列
    header_row = title_row + 1
    data_start = title_row + 2

    return header_row, data_start

# 24 Define function to find the end row of the data table for a node
# 24 定義函式：找出該 node 的資料結束列
def get_table_end(df, data_start, node_names_list):

    # 11) Slice column A after data_start / 只取 data_start 之後的 A 欄區段
    colA = df[0].fillna("").str.strip()
    scanA = colA.iloc[data_start-1:]
    #print(scanA.head(10).tolist())

    # 12) Stop when reaching next node / 遇到下一個 node 就停
    m_nodes = scanA.isin(node_names_list)
    #print(scanA[m_nodes].tolist())

    # 20) Fallback stop conditions / 備援停止條件（處理最後一個 node）
    m_general = scanA.str.startswith("[")
    m_setup = scanA.eq("Setup Stress Levels")
    m_idd2 = scanA.eq("IDD_2")

    # 21) Combine stop conditions / 合併停止條件
    stop_mask = m_nodes | m_general | m_setup | m_idd2

    # 13) Find first stop row / 找到第一個停止列
    #stop_i = m_nodes[m_nodes].index[0]
    stop_i = stop_mask[stop_mask].index[0]
    # print(stop_i)
    stop_row = stop_i + 1
    # print(stop_row)

    # 14) Table ends right before stop_row / 表格結束在 stop_row 的前一列
    table_end = stop_row - 1
    return table_end

# 19)  Extract one node and save to CSV / 抽一個 node 並存成 CSV
def extract_one(excel_path, df, target, node_names_list):

    header_row, data_start = get_data_start(df, target)

    table_end = get_table_end(df, data_start, node_names_list)

    # 6) Set target node / 設定目標node
    ###target = "{Part of Input1V89_POS_LH}"

    # 15) Rows to read (data only) / 要讀取的資料列數（不含header）
    nrows = table_end - header_row

    # 16) read table / 讀取表格
    df_tbl = pd.read_excel(
        excel_path,
        sheet_name="Summary",
        skiprows=header_row-1,
        header=0,
        nrows=nrows,
        engine="openpyxl"
    )
    ###print(df_tbl.columns)
    return df_tbl

# 17) Save extracted table / 保存抽出的表格
def save_table(df_tbl, name):
    df_tbl.to_csv(f"output/{name}.csv", index=False, encoding="utf-8-sig")
    #print("Saved:", f"output/{out_name}.csv", "| rows:", len(df_tbl))

# 29 Define function to process excel
# 29 定義函式: 處理 Excel 並批次抽取所有 node
def process_excel(excel_path=DEFAULT_EXCEL):
    df = load_summary_df(excel_path)
    raw_nodes_list, node_names_list, pairs_all = get_node_pairs(df)

    # 22) Run batch extraction for all nodes / 批次抽取所有的nodes
    for target, name in pairs_all:
        df_tbl = extract_one(excel_path, df, target, node_names_list)
        save_table(df_tbl, name)

# 25 Run process_excel() only when this script is executed directly
# 25 只有直接執行此檔案時才會跑 process_excel()（避免被 GUI import 時自動執行）
if __name__ == "__main__":
    process_excel()