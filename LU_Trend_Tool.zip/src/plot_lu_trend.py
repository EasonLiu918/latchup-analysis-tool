from pathlib import Path
import pandas as pd
# 8 Import node list / 匯入所有 node 名稱
#from src.list_test_nodes import node_names_list
# 9 Setup Plotting /添加畫圖套件
import matplotlib.pyplot as plt
# 27 Setup / 添加互動工具
import mplcursors
from matplotlib.lines import Line2D

# 5  Define function to convert current to mA / 定義函式：將電流統一轉成 mA
def convert_current(df):
        # 4 Find all is columns / 找出所有Is 欄位
        is_cols = ["Is1", "Is2", "Is3", "Is4", "Is5"]

        for col in is_cols:
                df[col + "_mA"] =0.0
                # 3 Loop through each row to convert Is / 逐列處理 Is
                for i in range(len(df)):
                        value = str(df[col][i])
                        # Case 1: value is uA / 如果是 uA
                        if "uA" in value:
                                df.at[i, col + "_mA"] = float(value.replace(" uA","")) / 1000
                        # Case 2: value is mA / 如果是 mA
                        elif "mA" in value:
                                df.at[i, col + "_mA"] = float(value.replace(" mA",""))
                        #print(df[[col + "_mA" for col in is_cols]])
        return df

#  19 Define function to convert voltage to float / 定義函式: 將電壓字串轉成數值
def convert_voltage(df):
        # 18 Find all is columns / 找出所有Vs 欄位
        vs_cols = ["Vs1","Vs2","Vs3","Vs4","Vs5"]

        for col in vs_cols:
                df[col + "_V"] = 0.0
                
                for i in range(len(df)):
                        value = str(df[col][i])
                        # Case 1: value is uV / 如果是uV (單位從小到大換算)
                        if "uV" in value:
                                df.at[i, col + "_V"] = float(value.replace(" uV","")) / 1000000
                        # Case 2: value is mV / 如果是mV
                        elif "mV" in value:
                                df.at[i, col + "_V"] = float(value.replace(" mV","")) / 1000
                        # Case 3: value is V / 如果是V
                        elif "V" in value:
                                df.at[i, col + "_V"] = float(value.replace(" V",""))
        return df

# 25 Define function to set x-axis range dynamically / 定義函式: 根據資料自動設定x軸範圍
def get_xlim(df_pre, df_stress, df_post, stage, vs_list):
        # 24 Collect only selected data / 只收被選擇的資料
        all_vs = []
        if "pre" in stage:
               for i in vs_list:
                       all_vs.extend(df_pre[f"Vs{i}_V"])

        if "stress" in stage:
               for i in vs_list:
                       all_vs.extend(df_stress[f"Vs{i}_V"])

        if "post" in stage:
               for i in vs_list:
                       all_vs.extend(df_post[f"Vs{i}_V"])

        vmin = min(all_vs)
        vmax = max(all_vs)

        print("vmin=", vmin)
        print("vmax=", vmax)

        margin = (vmax - vmin) * 0.1
        return vmin - margin, vmax + margin

# 26 Define function to set y-axis range dynamically / 定義函式: 根據資料自動設定y軸範圍
def get_ylim(df_pre, df_stress, df_post, stage, vs_list):
        all_is = []
        if "pre" in stage:
                for i in vs_list:
                        all_is.extend(df_pre[f"Is{i}_mA"])

        if "stress" in stage:
                for i in vs_list:
                        all_is.extend(df_stress[f"Is{i}_mA"])

        if "post" in stage:
                for i in vs_list:
                        all_is.extend(df_post[f"Is{i}_mA"])

        imin = min(all_is)
        imax = max(all_is)

        print("imin=", imin)
        print("imax=", imax)

        margin = (imax - imin) * 0.1
        return imin - margin, imax + margin

# 7  Define function to split stage data / 定義函式：分離 Pre / Stress / Post
def split_stage(df):
       # 6 Select stress/ 選擇 stress
       df_pre = df[df["Data Ordination"].str.contains("Pre-Stress")]
       df_stress = df[df["Data Ordination"].str.contains("Stress") &~df["Data Ordination"].str.contains("Pre-Stress")]
       df_post = df[df["Data Ordination"].str.contains("Post-Stress")]

       return df_pre, df_stress, df_post
# 29 Load CSV data for given node / 輸入node_name,讀取對應的csv並回傳Dataframe
def load_node_data(node_name):
                # 1 Load one node CSV / 讀取一個 node 的 CSV
                csv_path = Path(f"output/{node_name}.csv")
                df = pd.read_csv(csv_path)

                # 30 Ensure Pin column exists / 確保PIN欄位存在
                if "Pin" not in df.columns:
                        df["Pin"] = "N/A"
                return df
                

# 16 Define function to plot iv plot / 定義函式：畫 IV 圖
# 22 Define function to plot iv curves with selectable stages and voltage points / 定義函式：畫 IV 圖，支援選擇 stage 與 Vs 點
def plot_iv(df_pre, df_stress, df_post, node_name,
            stage=["pre","stress","post"],
            vs_list=[1,2,3,4,5]):
       
       # 20 Set figure size / 設定圖大小
       plt.figure(figsize=(12,7))
       
       # 27 Creat a list to collect all scatter objects / 收集畫出來的點
       sc_list = []

       # 35 Collect all data and get unique sorted pins for color mapping / 收集資料並準備 Pin→顏色 mapping
       all_df = pd.concat([df_pre,df_stress,df_post])
       unique_pins = all_df["Pin"].unique()
       unique_pins = sorted(unique_pins)

       # 36 Create color map for each Pin / 為每個Pin 分配顏色
       cmap = plt.cm.get_cmap("hsv", len(unique_pins))
       pin_color_map = {}

       for idx in range(len(unique_pins)):
               pin = unique_pins[idx]
               color = cmap(idx)
               pin_color_map[pin] = color
        
        # 37 Set color for N/A pin / 將沒有Pin 的資料設為灰色
       if "N/A" in pin_color_map:
                pin_color_map["N/A"] = "gray"
        
       print("df_pre Pin:", df_pre["Pin"].unique())
       print("color_map keys:", list(pin_color_map.keys()))

       # 14 Loop all / 逐一畫 Is1~Is5
       #for i in range(1, 6):
       # Plot selected Pre-Stress data if included in stages / 如果使用者選擇pre, 則畫Pre-Stress資料
       if "pre" in stage:
               for i in vs_list:
                       # 15 Add legend label only once for each stage / 每個 stage 只標記一次 label
                       #if i == 1:
                #        if i == vs_list[0]:
                #                sc = plt.scatter(df_pre[f"Vs{i}_V"], df_pre[f"Is{i}_mA"], marker="o", c = df_pre["Pin"].map(pin_color_map), s=20, alpha=0.5, label = "Pre-Stress")
                #                sc._df_source = df_pre
                #                sc._vs_index = i
                #                sc._stage = "Pre"
                #                sc_list.append(sc)
                #        else:
                               # 9 plot IV point / 畫 IV 圖
                               sc = plt.scatter(df_pre[f"Vs{i}_V"], df_pre[f"Is{i}_mA"], marker="o", c = df_pre["Pin"].map(pin_color_map), s=20, alpha=0.5)
                               sc._df_source = df_pre
                               sc._vs_index = i
                               sc._stage = "Pre"
                               sc_list.append(sc)


       # Plot selected Stress data if included in stages / 如果使用者選擇Stress, 則畫Stress資料
       if "stress" in stage:
               # for i in range(1, 6):
               for i in vs_list:
                       # 15 Add legend label only once for each stage / 每個 stage 只標記一次 label
                       # if i == 1:
                #        if i == vs_list[0]:
                #                sc = plt.scatter(df_stress[f"Vs{i}_V"], df_stress[f"Is{i}_mA"], marker="x", c = df_stress["Pin"].map(pin_color_map), s=20, alpha=0.5, label ="Stress")
                #                sc._df_source = df_stress
                #                sc._vs_index = i
                #                sc._stage = "Stress"
                #                sc_list.append(sc)
                #        else:
                               # 9 plot IV point / 畫 IV 圖
                               sc = plt.scatter(df_stress[f"Vs{i}_V"], df_stress[f"Is{i}_mA"], marker="x", c = df_stress["Pin"].map(pin_color_map), s=20, alpha=0.5)
                               sc._df_source = df_stress
                               sc._vs_index = i
                               sc._stage = "Stress"
                               sc_list.append(sc)

       # Plot selected Post-Stress data if included in stages / 如果使用者選擇Post-Stress, 則畫Post-Stress資料
       if "post" in stage:
               #for i in range(1, 6):
               for i in vs_list:
                       # 15 Add legend label only once for each stage / 每個 stage 只標記一次 label
                       # if i == 1:
                #        if i == vs_list[0]:
                #                sc = plt.scatter(df_post[f"Vs{i}_V"], df_post[f"Is{i}_mA"], marker="^", c = df_post["Pin"].map(pin_color_map), s=20, alpha=0.5, label ="Post-Stress")
                #                sc._df_source = df_post
                #                sc._vs_index = i
                #                sc._stage = "Post"
                #                sc_list.append(sc)
                #        else:
                               # 9 plot IV point / 畫 IV 圖
                               sc = plt.scatter(df_post[f"Vs{i}_V"], df_post[f"Is{i}_mA"], marker="^", c = df_post["Pin"].map(pin_color_map), s=20, alpha=0.5)
                               sc._df_source = df_post
                               sc._vs_index = i
                               sc._stage = "Post"
                               sc_list.append(sc)

       # 10 Add a label / 添加標籤
       plt.xlabel("Voltage(V)") 
       plt.ylabel("Current(mA)")
       plt.title(f"IV Plot - {node_name}")

       # 11 Add a legned / 添加圖例 # 11 Add legend label only once for each stage / 每個 stage 只標記一次 label
       # 21 Put legend outside / 把legend 放外面
#        plt.legend(loc="upper right", bbox_to_anchor=(1.15,1))
       # 38 Create fixed legend for stage markers / 固定顏色的stage 圖例 (不受Pin顏色影響)
       legend_elements = [
               Line2D([0],[0],marker="o", color="black", linestyle="None",
                      markersize=6, label="Pre-Stress"),
               Line2D([0],[0],marker="x", color="black", linestyle="None",
                      markersize=6, label="Stress"),
               Line2D([0],[0],marker="^", color="black", linestyle="None",
                      markersize=6, label="Post-Stress"),
       ]
       plt.legend(handles=legend_elements, loc="upper right", bbox_to_anchor=(1.15,1))
       plt.grid()
       
       # 28 Create a single cursor for all scatter objects / 讓滑鼠移上去可以顯示資訊
       cursor = mplcursors.cursor(sc_list, hover = True)
       @cursor.connect("add")
       def on_add(sel):
               # 31 Get the scatter object that was hovered / 取得目前滑鼠指到的 scatter 物件
               artist = sel.artist
               # 32 Get the original DataFrame and Vs index / 取得原始 DataFrame 與 Vs 編號
               df_source = artist._df_source
               vs_idx = artist._vs_index
               # 33 Get the row corresponding to the hovered point / 取得滑鼠指到的那一列資料
               row = df_source.iloc[sel.index]
               # 34 Get x, y, and Pin values / 取得 x、y 與 Pin 值
               x = row[f"Vs{vs_idx}_V"]
               y = row[f"Is{vs_idx}_mA"]
               pin_value = row["Pin"] if "Pin" in row.index else "N/A"

               # 28 Retrieve the x and y coordinates of selected point / 取得滑鼠指到的點座標
               # x, y = sel.target
               # 28 Set the text to display in the tooltip / 設定顯示文字格式
               sel.annotation.set_text(
                       f"Pin: {pin_value}\n"
                       f"Voltage: {x:<8} V\n"
                       f"Current: {y:<8} mA"    
               )

       xmin, xmax = get_xlim(df_pre, df_stress, df_post, stage, vs_list)
       ymin, ymax = get_ylim(df_pre, df_stress, df_post, stage, vs_list)
       
       # 12 Save the image / 存圖片
       # node_name = "Input1V89_NEG_LH"
       #plt.savefig(f"plots/iv_plot_{node_name}.png", bbox_inches="tight")

       # 13 Clear figure / 清空畫布
       #plt.clf()
       plt.show()
       #return plt.gcf() # Return figure object / 回傳圖形(讓gui可以顯示)

def main():
        # 17 Loop all node / 逐一讀取node
        #for node_name in node_names_list:

        node_name = "Input1V89_POS_LH"
        # 29 Load CSV data for given node / 輸入node_name,讀取對應的csv並回傳Dataframe
        df = load_node_data(node_name)

        # 5  Apply current conversion function / 執行電流轉換（轉成 mA）
        df = convert_current(df)
        #print(df["Is1"])
        # 20 Apply voltage conversion function / 執行電壓轉換( 轉成 float)
        df = convert_voltage(df)
        # 2 Initialize new column for converted current (mA) / 建立新欄位存轉換後的電流(mA)
        #df["Is1_mA"] = 0
        #print(len(df))
        # 7  Apply function / 執行資料分群（取得 Pre / Stress / Post）
        df_pre, df_stress, df_post = split_stage(df)
        # 16  Apply function / 執行畫圖
        plot_iv(df_pre, df_stress, df_post, node_name,
                stage=["pre", "post"],
                vs_list=[1])
        
# 28 Run main() only when this script is executed directly
# 28 只有直接執行此檔案時才會跑 main()（避免被 GUI import 時自動執行）
if __name__ == "__main__":
        main()